# 🏭 자재일정 협력사 챗봇

협력사별 자재 입출 일정을 실시간으로 조회할 수 있는 Streamlit 챗봇입니다.  
`data/material_schedule.xlsx` 데이터를 기반으로 협력사 코드(A열)를 인식하고,  
작업일자·요청일자·인수일자·수량 등을 자연어로 조회할 수 있습니다.

## ⚙️ 실행 방법
```bash
streamlit run app_material_schedule_v16_fix_titleAcol.py --server.port 8502
```

## 📁 폴더 구조
```
📁 data → material_schedule.xlsx (협력사별 데이터)
📄 app_material_schedule_v16_fix_titleAcol.py → 메인 Streamlit 실행파일
```

## 💡 사용 예시
- “A001” 코드로 조회 → A001 협력사 데이터만 표시  
- “11월 11일 작업완료?” → 해당일 작업여부와 수량 표시  
- “인수완료?” → 인수일자 기반 상태 표시  

## 🛡️ 보안 주의
`data/material_schedule.xlsx`는 **협력사 데이터이므로 깃허브 업로드 금지!**  
`.gitignore`에 이미 제외 설정되어 있습니다.
